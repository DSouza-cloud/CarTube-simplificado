import { useEffect, useRef, useState } from 'react';

const memory = new Map<string, string>();
export const STORAGE_FAIL_EVENT = 'cartube-storage-fail';

export function readStorage<T>(key: string, initial: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
  } catch {
    const raw = memory.get(key);
    if (raw) return JSON.parse(raw) as T;
  }
  return initial;
}

export function writeStorage(key: string, value: unknown): boolean {
  const raw = JSON.stringify(value);
  memory.set(key, raw);
  try {
    localStorage.setItem(key, raw);
    return true;
  } catch {
    window.dispatchEvent(new Event(STORAGE_FAIL_EVENT));
    return false;
  }
}

/** useState que persiste no localStorage a cada mudança. */
export function useStoredState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => readStorage(key, initial));
  const skipFirst = useRef(true);
  useEffect(() => {
    if (skipFirst.current) {
      skipFirst.current = false;
      return;
    }
    writeStorage(key, value);
  }, [key, value]);
  return [value, setValue] as const;
}

export function requestPersistentStorage() {
  try {
    navigator.storage?.persist?.();
  } catch {
    /* ignore */
  }
}
