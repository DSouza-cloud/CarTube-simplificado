import { Video } from '../types';

export const uid = () =>
  (globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now().toString(36));

export const thumbUrl = (v: Video) =>
  v.videoId ? `https://i.ytimg.com/vi/${v.videoId}/mqdefault.jpg` : '';

export const watchUrl = (v: Video) =>
  v.videoId
    ? `https://www.youtube.com/watch?v=${v.videoId}`
    : `https://www.youtube.com/playlist?list=${v.playlistId}`;

/** Extrai videoId / playlistId de links ou IDs soltos. */
export function parseYouTube(input: string): { videoId?: string; playlistId?: string } | null {
  const text = input.trim();
  if (!text) return null;
  if (/^[\w-]{11}$/.test(text) && !/\s/.test(text)) return { videoId: text };
  if (/^(PL|UU|LL|FL|RD|OL)[\w-]{10,}$/.test(text)) return { playlistId: text };
  if (!/youtu\.?be/.test(text)) return null;

  const playlistId = text.match(/[?&]list=([\w-]+)/)?.[1];
  const videoId =
    text.match(/[?&]v=([\w-]{11})/)?.[1] ||
    text.match(/youtu\.be\/([\w-]{11})/)?.[1] ||
    text.match(/youtube(?:-nocookie)?\.com\/(?:shorts|embed|live)\/([\w-]{11})/)?.[1];

  if (!videoId && !playlistId) return null;
  return { videoId, playlistId };
}

const decode = (s: string) => {
  const t = document.createElement('textarea');
  t.innerHTML = s;
  return t.value;
};

/** Título e canal sem precisar de chave de API. */
export async function fetchOEmbed(videoId: string): Promise<{ title: string; channel: string } | null> {
  try {
    const url = `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(
      `https://www.youtube.com/watch?v=${videoId}`,
    )}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    return { title: data.title, channel: data.author_name };
  } catch {
    return null;
  }
}

async function api(path: string, params: Record<string, string>, key: string) {
  const qs = new URLSearchParams({ ...params, key });
  const res = await fetch(`https://www.googleapis.com/youtube/v3/${path}?${qs}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || `Erro ${res.status} na API do YouTube`);
  return data;
}

export async function searchVideos(query: string, key: string, max = 25): Promise<Video[]> {
  const data = await api(
    'search',
    {
      part: 'snippet',
      type: 'video',
      videoEmbeddable: 'true',
      maxResults: String(max),
      q: query,
    },
    key,
  );
  return (data.items || [])
    .filter((i: any) => i.id?.videoId)
    .map((i: any) => ({
      id: uid(),
      videoId: i.id.videoId,
      title: decode(i.snippet.title),
      channel: decode(i.snippet.channelTitle),
    }));
}

export async function fetchPlaylistVideos(playlistId: string, key: string, max = 200): Promise<Video[]> {
  const out: Video[] = [];
  let pageToken = '';
  while (out.length < max) {
    const params: Record<string, string> = { part: 'snippet', maxResults: '50', playlistId };
    if (pageToken) params.pageToken = pageToken;
    const data = await api('playlistItems', params, key);
    for (const i of data.items || []) {
      const vid = i.snippet?.resourceId?.videoId;
      const title = i.snippet?.title;
      if (!vid || title === 'Private video' || title === 'Deleted video') continue;
      out.push({
        id: uid(),
        videoId: vid,
        title: decode(title),
        channel: decode(i.snippet.videoOwnerChannelTitle || ''),
      });
    }
    pageToken = data.nextPageToken;
    if (!pageToken) break;
  }
  return out;
}

/** Resolve o que o usuário colou (link de vídeo ou playlist) em itens prontos. */
export async function resolveLink(input: string, key: string): Promise<{ videos: Video[]; note?: string } | null> {
  const parsed = parseYouTube(input);
  if (!parsed) return null;

  if (parsed.playlistId && key) {
    const videos = await fetchPlaylistVideos(parsed.playlistId, key);
    if (videos.length) return { videos };
  }
  if (parsed.videoId) {
    const meta = await fetchOEmbed(parsed.videoId);
    return {
      videos: [
        { id: uid(), videoId: parsed.videoId, title: meta?.title || 'Vídeo do YouTube', channel: meta?.channel || '' },
      ],
      note: parsed.playlistId && !key ? 'Adicionei só o vídeo. Para importar a playlist inteira, configure a chave da API.' : undefined,
    };
  }
  return {
    videos: [{ id: uid(), playlistId: parsed.playlistId, title: 'Playlist do YouTube', channel: 'Toca direto no player' }],
    note: 'Playlist adicionada sem lista de vídeos. Configure a chave da API para importar e editar cada vídeo.',
  };
}

let apiPromise: Promise<any> | null = null;
export function loadYouTubeApi(): Promise<any> {
  if ((window as any).YT?.Player) return Promise.resolve((window as any).YT);
  if (!apiPromise) {
    apiPromise = new Promise((resolve) => {
      const prev = (window as any).onYouTubeIframeAPIReady;
      (window as any).onYouTubeIframeAPIReady = () => {
        prev?.();
        resolve((window as any).YT);
      };
      const s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(s);
    });
  }
  return apiPromise;
}
