export interface Video {
  id: string; // id interno único (diferente do videoId do YouTube)
  videoId?: string;
  playlistId?: string; // usado só quando é uma playlist do YouTube não importada
  title: string;
  channel: string;
}

export interface Playlist {
  id: string;
  name: string;
  items: Video[];
}
