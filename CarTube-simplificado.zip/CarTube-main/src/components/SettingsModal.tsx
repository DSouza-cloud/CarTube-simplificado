import { useState } from 'react';
import { X } from 'lucide-react';

interface Props {
  apiKey: string;
  onSave: (key: string) => void;
  onClose: () => void;
}

export function SettingsModal({ apiKey, onSave, onClose }: Props) {
  const [key, setKey] = useState(apiKey);
  return (
    <div className="fixed inset-0 z-[60] bg-black/80 flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-white">Configurações</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <label className="block mt-4 text-xs font-semibold text-slate-300">Chave da API do YouTube (Data API v3)</label>
        <input
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="AIza..."
          className="mt-1 w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white outline-none focus:border-red-500"
        />
        <ol className="mt-3 text-xs text-slate-400 list-decimal pl-4 space-y-1">
          <li>Acesse console.cloud.google.com e crie um projeto.</li>
          <li>Ative a “YouTube Data API v3”.</li>
          <li>Em Credenciais, crie uma “Chave de API” e cole aqui.</li>
        </ol>
        <p className="mt-2 text-xs text-slate-500">
          Ela habilita a busca pela lupa e a importação de playlists inteiras. Sem a chave, só links diretos funcionam.
        </p>

        <button
          onClick={() => {
            onSave(key.trim());
            onClose();
          }}
          className="mt-4 w-full py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm"
        >
          Salvar
        </button>
      </div>
    </div>
  );
}
